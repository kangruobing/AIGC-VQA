Runtime per video [s]: 1.92
Flops [GFLOPs]: 45.3
CPU[1] / GPU[0]: 0
Extra Data use: 1
LLM use: 0
Others: The details about the code producing the provided results (dependencies, links, scripts, etc.).